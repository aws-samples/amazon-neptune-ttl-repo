#!/usr/bin/env pthon
# -*- coding: utf-8 -*-

# Copyright 2019 Amazon.com, Inc. or its affiliates.
# All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
#    http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file.
# This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
# either express or implied. See the License for the specific language governing permissions
# and limitations under the License.


from __future__ import print_function  # Python 2/3 compatibility

import logging
import os

from commons import *

logging.basicConfig(filename='stream.log', encoding='utf-8', level=logging.DEBUG)

"""
This class can be used to test Poller changes locally on dev machine against local Neptune.
Below are the steps need to be done to get the setup running -
1) Setup ES locally on dev machine. (https://www.elastic.co/guide/en/elasticsearch/reference/current/targz.html)
2) Check if ES is running doing a health check
3) Start Neptune server locally on the dev machine. Ensure Streams is enabled on Neptune.
4) In set_env_variable change the value of 'NeptuneStreamEndpoint', 'AdditionalParams.ElasticSearchEndpoint'.
   You can also change other variables as per your usecase.
5) Run the main method.   
"""

retry_count = 0


def reset_retry_count():
    global retry_count
    retry_count = 0


def set_env_variable():
    os.environ['AWS_REGION'] = 'us-east-1'
    os.environ['StreamRecordsBatchSize'] = "100"
    os.environ['MaxPollingWaitTime'] = "2"
    os.environ['MaxPollingInterval'] = "100"
    os.environ['Application'] = "test"
    os.environ['LeaseTable'] = "test"
    os.environ['NeptuneStreamEndpoint'] = "https://database-2-instance-1.critvszpmydm.us-east-1.neptune.amazonaws.com:8182/propertygraph/stream"
    os.environ['StreamRecordsHandler'] = "neptune_to_neptune.neptune_to_neptune_gremlin_handler.NeptuneGremlinHandler"
    os.environ['AdditionalParams'] = '{ "NeptuneCluster": "database2-4xl.critvszpmydm.us-east-1.neptune.amazonaws.com:8182", "TargetSPARQLUpdateEndpoint": "", "IAMAuthEnabledOnTargetCluster": "false", "targetRegion": "us-east-1", "SPARQLTripleOnlyMode": "false", "BlockSparqlReplicationOnBlankNode": "true"}'
    os.environ['LoggingLevel'] = 'DEBUG'

def ec2_handler():

    """
    Main handler
    This is invoked when Lambda is called.
    This lambda function do below steps sequentially:
    1. Take Lease
    2. Poll for records from Stream until no records or 90% of Lambda Execution time is reached
    3. Stream records are passed to appropriate handlers. If no records are found lambda exists &
     pass wait_time to state machine
    4. Metrics are published to Cloud watch
    """
    from config_provider import config_provider
    from stream_records_processor import StreamRecordsProcessor

    # global variables
    stream_records_processor = StreamRecordsProcessor()
    # Logger
    logger = logging.getLogger(__name__)
    logger.setLevel(config_provider.logging_level)
    wait_time = 0
    checkpoint = '0'
    checkpoint_sub_sequence_number = '0'
    try:
        while True:
            results, stream_log = stream_records_processor.process(config_provider.stream_records_batch_size,
                                                                   checkpoint, checkpoint_sub_sequence_number)

            if results is None:
                # No records in Stream
                logger.info("No more stream records to process.")
                # Wait exponentially till max polling wait time
                wait_time = get_wait_time(config_provider.max_polling_wait_time, wait_time)
                time.sleep(wait_time)
            else:
                # When Stream records are processed in small chunks by handler, handle_records method returns
                # series of results one-by-one on Demand using Python Generators.
                # Each iteration will compute result object lazily which can further be used to update checkpoint.
                for result in results:
                    checkpoint_sub_sequence_number = result.last_op_num
                    checkpoint = result.last_commit_num
                    logger.info("Updated checkpoint, subSequenceNumber  to ({}, {})"
                                .format(checkpoint, checkpoint_sub_sequence_number))

                logger.info("Finished processing Stream records. Last Processed event id (commitNum, OpNum) - {} , {}"
                            .format(stream_log[LAST_EVENT_ID][COMMIT_NUM_STR], stream_log[LAST_EVENT_ID][OP_NUM_STR]))

            # Reset retry count as code executed successfully.
            reset_retry_count()
    except Exception as e:
        logger.error("Error Occurred while processing records - {}.".format(str(e)))
        raise e


def main():
    try:
        set_env_variable()
        ec2_handler()
    except Exception as e:
        global retry_count
        retry_count = retry_count + 1
        if retry_count < 5:
            ec2_handler()


if __name__ == "__main__":
    main()
